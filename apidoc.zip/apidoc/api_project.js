define({
  "name": "Edwisor Backend App",
  "version": "0.0.1",
  "description": "Documentation for the Edwisor Backend app",
  "title": "EdwisorBackendAPI",
  "url": "http://localhost:3000",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-08-08T09:13:47.659Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
